





<!DOCTYPE html>
<html>
<head>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-N3TTPM5L');</script>
<!-- End Google Tag Manager -->

    <meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
	<title>Спасибо за заказ!</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel='stylesheet' href='css/template.css' type='text/css' media='all' />

</head>
<body>
    
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-N3TTPM5L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<style>
body {
  background-image: url(fon1.png);
  
  /* Выравнивание картинки по центру */
  background-position: center center;
  
  background-repeat: no-repeat;
  
  background-attachment: fixed;
  
  /* Изменение размера картинки, в зависимости от экрана */
  background-size: cover;
  
  background-color: #3D3D3D;
}
 
/* adaptive */
@media only screen and (max-width: 767px) {
  body {
    background-image: url(mobile.png);
  }
}
  </style>
<br/>
<center>
<a style="display: block;
    margin: 0 auto;
    width: 100%;
    max-width: 600px;
    font-size: 22px;
    background: #000000;
    opacity: 0.8;
    color: #fff;
    padding: 10px 0;
    text-align: center;
    text-decoration: none;
    border-radius: 33px;"
<img align='center' src='index.png'></center>
<div class='wrap_block_success'>
<div class='block_success'>
    <h1 style='color:#f90; text-align: center;' >Поздравляем! Ваш заказ принят!</h1>
<h3 style='color:#f90; text-align: center;' >В ближайшее время с вами свяжется оператор для подтверждения заказа.<p пожалуйста, включите ваш контактный телефон.></p>
</h3>
<h1 style='color:#f90; text-align: center;' >Спасибо, что выбрали нас!</h1>
<br>
<a style="display: block;
    margin: 0 auto;
    width: 100%;
    max-width: 400px;
    font-size: 22px;
    background: #9e5f00;
    color: #fff;
    padding: 10px 0;
    text-align: center;
    text-decoration: none;
    border-radius: 33px;" href="../">Вернуться на главную</a>
</div>

</body>
</html>