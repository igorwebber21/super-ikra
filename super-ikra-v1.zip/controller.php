<?php


echo phpinfo();
print_r($_POST);

/*

Name: Макс
Phone: 0506789432
Quantity:  Кета 2 по 0,5 = 1160 грн.
comm: Кета в один клік
ip: 31.128.76.48

formId: form4, form5, form7

*/


/*


Name: цауца
lastName: цуауца
Phone: 0689182663
City: Одесса
Department: №233
Quantity:  Щука 2 по 0,5 = 1000 грн. + 0.5 в подарунок!
comm: Акція 1+1=3в
ip: 31.128.76.48
formId: form3

*/


 